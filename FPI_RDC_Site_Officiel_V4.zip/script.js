
const paymentOptions = {
    "Democratic Republic of the Congo": ["Airtel Money", "M-Pesa", "Orange Money"],
    "France": ["Carte bancaire", "PayPal", "Stripe"],
    "United States": ["Carte bancaire", "PayPal", "Stripe", "Crypto"],
    "default": ["PayPal", "Carte bancaire internationale"]
};

function showForm(projectName, investAmount, expectedAmount, duration) {
    document.getElementById('investment-form').classList.remove('hidden');
    document.getElementById('project').value = projectName;
    document.getElementById('amount').value = investAmount;
    document.getElementById('duration').value = duration;
    document.getElementById('confirmation').classList.add('hidden');
    detectCountry();
}

function closeForm() {
    document.getElementById('investment-form').classList.add('hidden');
}

function detectCountry() {
    const countryInput = document.getElementById('country');
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${position.coords.latitude}&lon=${position.coords.longitude}`)
            .then(response => response.json())
            .then(data => {
                let countryName = data.address.country || "Unknown";
                countryInput.value = countryName;
                updatePaymentOptions(countryName);
            }).catch(() => {
                countryInput.value = "";
                updatePaymentOptions("default");
            });
        }, () => {
            countryInput.value = "";
            updatePaymentOptions("default");
        });
    } else {
        countryInput.value = "";
        updatePaymentOptions("default");
    }
}

function updatePaymentOptions(country) {
    const paymentSelect = document.getElementById('payment');
    paymentSelect.innerHTML = "";
    let options = paymentOptions[country] || paymentOptions["default"];
    options.forEach(opt => {
        let optionElement = document.createElement("option");
        optionElement.value = opt;
        optionElement.textContent = opt;
        paymentSelect.appendChild(optionElement);
    });
}

document.getElementById('form').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const city = document.getElementById('city').value;
    const phone = document.getElementById('phone').value;
    const country = document.getElementById('country').value || "Non spécifié";
    const amount = document.getElementById('amount').value;
    const project = document.getElementById('project').value;
    const payment = document.getElementById('payment').value;
    const duration = document.getElementById('duration').value;
    document.getElementById('confirmation').textContent = 
        `Merci ${name} de ${city}, ${country}. Votre investissement de $${amount} dans ${project} via ${payment} est confirmé. Téléphone : ${phone}. Durée : ${duration}.`;
    document.getElementById('confirmation').classList.remove('hidden');
    // Ici, on peut envoyer les données au backend pour SMS/email
    this.reset();
});

document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const cname = document.getElementById('cname').value;
    document.getElementById('cconfirmation').textContent = 
        `Merci ${cname}, votre message a été envoyé!`;
    document.getElementById('cconfirmation').classList.remove('hidden');
    this.reset();
});
